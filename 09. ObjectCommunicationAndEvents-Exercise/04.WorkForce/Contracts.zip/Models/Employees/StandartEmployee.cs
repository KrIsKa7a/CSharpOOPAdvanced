﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.WorkForce.Models.Employees
{
    public class StandartEmployee : Employee
    {
        public StandartEmployee(string name) 
            : base(name, 40)
        {

        }
    }
}
