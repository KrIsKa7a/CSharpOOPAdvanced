﻿using _04.WorkForce.Controllers;
using System;

namespace _04.WorkForce
{
    class Program
    {
        static void Main(string[] args)
        {
            var engine = new Engine();

            engine.Run();
        }
    }
}
